PETUNJUK PENGERJAAN UJIAN AKHIR SEMESTER - PRAKTIKUM PEMROGRAMAN WEB
--------------------------------------------------------------------

Buatlah aplikasi Presensi Mahasiswa dengan ketentuan sebagai berikut:
1. Pengguna aplikasi adalah Dosen (role: dosen) dan Staf Admin Prodi (role: admin). 
2. Dosen bekerja di sisi front-end (file: index.php) dan Staf Admin Prodi bekerja di sisi back-end (/admin/____.php). 
3. Kedua pengguna harus Login terlebih dahulu sebelum melakukan tugasnya, ini dikelola di akun user (gunakan akun user seperti pada Tugas Latihan di kelas)
4. Ketika Dosen mengisi Presensi, seluruh daftar Nama Mahasiswa beserta NIM-nya akan dimuat secara dinamis saat field Kelas dipilih, (misalkan pilihan: 5A, maka akan ditampilkan daftar seluruh mahasiswa kelas A, dan jika pilihan: 5B, ditampilkan mahasiswa kelas B).
5. Daftar nama mahasiswa setiap kelas dikelola/ diisi oleh Staf Admin Prodi. Datanya tersimpan di tabel: mahasiswa
6. Hasil pengisian Presensi tersimpan di tabel: presensi dan dapat dilihat oleh Staf Admin Prodi di halaman dashboard-nya.
7. Struktur tabel mahasiswa dan presensi dapat di import dari file sql yang disediakan (mahasiswa.sql dan presensi.sql)
8. Batas waktu pengerjaan sampai 21 November 2022 pukul 23.00 WIB
